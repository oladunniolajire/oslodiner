## oslo_diner
 Oslo Diner website with Rave Flutterwave payment gateway
 
 To vist the site <a href="https://oslo-diner.github.io/oslodiner/">CLICK HERE</a>

## To try out the payment gateway use these dummy Card deatils 

#Test MasterCard PIN authentication
- 5531 8866 5214 2950
- cvv 564
- Expiry: 09/22
- Pin 3310
- otp 12345

#Test Visa Card 3D-Secure authentication
- 4187 4274 1556 4246
- cvv: 828
- Expiry: 09/21
- Pin 3310
- otp 12345

#Test Verve Card (PIN)
- 5061 4604 1012 0223 210
- Expiry Month 12
- Expiry Year 21
- cvv: 780
- Pin: 3310
- otp 12345

##Contributors: 