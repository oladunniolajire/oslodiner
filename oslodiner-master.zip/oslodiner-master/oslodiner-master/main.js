function Redirect() {
    window.location.assign("./menu/menu.html");
}